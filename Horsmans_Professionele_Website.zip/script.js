'use strict';
const PHONE='31630280618';
const EMAIL='info@horsmansspecialistischereiniging.com';
const icons={
 'building':'<rect x="4" y="3" width="16" height="18" rx="1"/><path d="M9 7h1m4 0h1M9 11h1m4 0h1M9 15h1m4 0h1M10 21v-4h4v4"/>',
 'droplets':'<path d="M12 3c-3 4-7 8-7 12a7 7 0 0 0 14 0c0-4-4-8-7-12Z"/><path d="M9 17a3 3 0 0 0 3 3"/>',
 'window':'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M12 3v18M3 12h18"/>',
 'brush':'<path d="m14 6 4 4M4 20l7-7 5 5-7 3-5-1ZM13 12l7-7a2 2 0 0 0-3-3l-7 7"/>',
 'key':'<path d="M8 15a6 6 0 1 1 5-2l-2 2H8v3H5v3H2v-4l6-2Z"/>',
 'truck':'<path d="M3 6h11v12H3zM14 10h4l3 4v4h-7z"/><circle cx="7.5" cy="19" r="2"/><circle cx="17.5" cy="19" r="2"/>',
 'alert':'<path d="m12 2 10 18H2L12 2Z"/><path d="M12 9v5m0 3h.01"/>',
 'sofa':'<path d="M4 12V8a3 3 0 0 1 3-3h10a3 3 0 0 1 3 3v4M4 17h16M4 20v-2H2v-5a2 2 0 0 1 4 0v3h12v-3a2 2 0 0 1 4 0v5h-2v2M4 20v2m16-2v2"/>',
 'layers':'<path d="m12 2 10 5-10 5L2 7l10-5ZM2 12l10 5 10-5M2 17l10 5 10-5"/>',
 'factory':'<path d="M3 21V10l6 3V9l6 3V5h6v16H3ZM6 17h1m4 0h1m5 0h1"/>',
 'sparkles':'<path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3ZM19 17l.7 2.3L22 20l-2.3.7L19 23l-.7-2.3L16 20l2.3-.7L19 17Z"/>',
 'shield':'<path d="M12 2 20 6v6c0 5-3.5 8-8 10-4.5-2-8-5-8-10V6l8-4Z"/><path d="m8.5 12 2.5 2.5 5-5"/>',
 'clock':'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 'messages':'<path d="M20 11a7 7 0 0 1-7 7H7l-4 3v-6a7 7 0 1 1 17-4Z"/><path d="M9 10h8m-8 4h5"/>',
 'message-circle':'<path d="M21 11.5a8.4 8.4 0 0 1-9 8.5 8.5 8.5 0 0 1-4-.9L3 21l1.9-5A8.5 8.5 0 1 1 21 11.5Z"/>',
 'clipboard':'<rect x="5" y="4" width="14" height="18" rx="2"/><rect x="9" y="2" width="6" height="4" rx="1"/><path d="M9 12h6m-6 4h6"/>',
 'target':'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>'
};
function svg(name){return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name]||icons.sparkles}</svg>`}
document.querySelectorAll('[data-icon]').forEach(el=>{el.innerHTML=svg(el.dataset.icon)});
const services=[
 {title:'Gevel- & dakreiniging',desc:'Professioneel reinigen van gevels, daken en buitenoppervlakken.',icon:'building',cat:['buiten']},
 {title:'Oppervlaktereiniging',desc:'Opritten, bestrating, parkeerplaatsen en bedrijfsterreinen.',icon:'droplets',cat:['buiten']},
 {title:'Glasbewassing',desc:'Glas en kozijnen voor particulieren, bedrijven en VvE’s.',icon:'window',cat:['buiten','binnen']},
 {title:'Verf- & graffitiverwijdering',desc:'Onze specialiteit: gerichte verwijdering met oog voor de ondergrond.',icon:'brush',cat:['specialistisch','buiten'],featured:true},
 {title:'Opleveringsschoonmaak',desc:'Grondige schoonmaak voor een nette oplevering van panden.',icon:'key',cat:['binnen']},
 {title:'Ontruiming',desc:'Ondersteuning bij het leegmaken en schoon achterlaten van ruimten.',icon:'truck',cat:['binnen','specialistisch']},
 {title:'Calamiteitenschoonmaak',desc:'Reinigingswerkzaamheden na onverwachte vervuiling of incidenten.',icon:'alert',cat:['specialistisch']},
 {title:'Meubel- & tapijtreiniging',desc:'Diepgaande reiniging van stoffering, meubels en tapijt.',icon:'sofa',cat:['binnen']},
 {title:'Vloeronderhoud',desc:'Reiniging en onderhoud van diverse harde vloertypen.',icon:'layers',cat:['binnen']},
 {title:'Industriële reiniging',desc:'Reinigingsoplossingen voor professionele en industriële omgevingen.',icon:'factory',cat:['specialistisch']},
 {title:'Dieptereiniging',desc:'Intensieve reiniging van sterk vervuilde oppervlakken en ruimten.',icon:'sparkles',cat:['binnen','specialistisch']},
 {title:'Kleurherstellende coating',desc:'Opfrissen en beschermen van geschikte verkleurde oppervlakken.',icon:'shield',cat:['buiten','specialistisch']}
];
const grid=document.getElementById('services-grid');
function renderServices(category='all'){
 const matched=services.filter(s=>category==='all'||s.cat.includes(category));
 grid.innerHTML=matched.map((s,i)=>`<article class="service-card${s.featured?' featured':''}" style="animation-delay:${Math.min(i*35,250)}ms"><span class="service-icon">${svg(s.icon)}</span>${s.featured?'<span class="service-tag">ONZE SPECIALITEIT</span>':''}<h3>${s.title}</h3><p>${s.desc}</p><a class="service-arrow" href="#offerte" aria-label="Offerte aanvragen voor ${s.title}">↗</a></article>`).join('');
}
renderServices();
const select=document.querySelector('select[name="dienst"]');
services.forEach(s=>{const opt=document.createElement('option');opt.value=s.title;opt.textContent=s.title;select.appendChild(opt)});
document.querySelectorAll('.filter').forEach(button=>button.addEventListener('click',()=>{document.querySelectorAll('.filter').forEach(b=>{b.classList.remove('active');b.setAttribute('aria-pressed','false')});button.classList.add('active');button.setAttribute('aria-pressed','true');renderServices(button.dataset.filter)}));
const menuButton=document.querySelector('.menu-toggle');const nav=document.querySelector('.main-nav');
menuButton.addEventListener('click',()=>{const isOpen=nav.classList.toggle('open');menuButton.setAttribute('aria-expanded',String(isOpen));menuButton.setAttribute('aria-label',isOpen?'Menu sluiten':'Menu openen')});
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menuButton.setAttribute('aria-expanded','false')}));
document.getElementById('year').textContent=new Date().getFullYear();
window.addEventListener('scroll',()=>{document.querySelector('.site-header').classList.toggle('scrolled',window.scrollY>20)},{passive:true});
const revealObserver='IntersectionObserver' in window?new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');revealObserver.unobserve(e.target)}}),{threshold:.08}):null;
document.querySelectorAll('.reveal').forEach(el=>{if(revealObserver)revealObserver.observe(el);else el.classList.add('visible')});
document.getElementById('close-wa-tip').addEventListener('click',()=>{document.getElementById('whatsapp-tip').hidden=true});
const form=document.getElementById('quote-form');const error=document.getElementById('form-error');
function prepareMessage(){
 error.hidden=true;
 if(!form.checkValidity()) {form.reportValidity();error.textContent='Vul alle verplichte velden in en geef toestemming om contact op te nemen.';error.hidden=false;return null}
 const data=new FormData(form);
 return `Hallo Horsmans, ik wil graag een gratis adviesgesprek en een vrijblijvende offerte aanvragen.\n\nNaam: ${data.get('naam')}\nTelefoon: ${data.get('telefoon')}\nE-mail: ${data.get('email')}\nPlaats/postcode: ${data.get('locatie')||'Niet opgegeven'}\nDienst: ${data.get('dienst')}\n\nOmschrijving:\n${data.get('bericht')}\n\nGraag ontvang ik een reactie over de mogelijkheden.`;
}
form.addEventListener('submit',e=>{e.preventDefault();const msg=prepareMessage();if(msg)window.open(`https://wa.me/${PHONE}?text=${encodeURIComponent(msg)}`,'_blank','noopener,noreferrer')});
document.getElementById('email-submit').addEventListener('click',()=>{const msg=prepareMessage();if(msg)window.location.href=`mailto:${EMAIL}?subject=${encodeURIComponent('Offerteaanvraag via website Horsmans')}&body=${encodeURIComponent(msg)}`});
