HORSMANS SPECIALISTISCHE REINIGING — NIEUWE WEBSITE
==================================================

DE WEBSITE OPENEN
1. Pak het ZIP-bestand uit.
2. Dubbelklik op index.html voor een lokale preview.
3. Upload de inhoud van de map naar de webhosting (meestal public_html).

INHOUD
- index.html  : de volledige Nederlandse homepage
- styles.css : responsive design, kleurgebruik, animaties
- script.js  : 12 diensten, filtering, mobiel menu, WhatsApp-offerteformulier

WAT WERKT ER
- 100% responsive voor smartphone, tablet en desktop
- Mobiel hamburgermenu en sticky navigatie
- Twaalf diensten met interactieve filters
- WhatsApp zweefknop naar bestaand nummer: +31 6 30 28 06 18
- Offerteformulier met verplichte velden, validatie, WhatsApp-verzending en e-mailalternatief
- Animaties met respect voor instelling voor minder beweging
- E-mailadres van bestaande website: info@horsmansspecialistischereiniging.com
- Geen gratis-proefstuk-promoties meer

BELANGRIJK VOOR LIVEGANG
- De foto's zijn externe Unsplash-sfeerbeelden, GEEN eigen projecten. Er is dus internet
  nodig om deze sfeerfoto's te laden. Vervang deze voor publicatie door eigen foto's.
- Er staan bewust GEEN verzonnen Google-reviews of certificeringen op de site.
  Voeg uitsluitend echte klantbeoordelingen toe wanneer je die hebt.
- Het offerteformulier gebruikt WhatsApp of mailto en heeft GEEN server/backend.
  De website ontvangt niet zelf e-mails en bewaart geen klantgegevens.
  Een professionele backend, spambeveiliging en AVG-documentatie kun je later toevoegen.
- Controleer of de toezegging 'offerte binnen 24 uur' haalbaar is.
- De gebruikte groene stijl is een premium interpretatie; controleer deze aan de hand van
  je exacte huisstijl als je daarvoor kleurcodes hebt.
- Voeg voor publicatie je bedrijfsgegevens, privacyverklaring en eventuele cookie-toestemming
  toe als je analytics of tracking plaatst.
- Voor de contact- en offerteteksten geldt: controleer je dienstverlening voordat je live gaat.

AANPASSEN
- Bedrijfsnummer en e-mailadres: zoek in index.html en script.js.
- Diensten: bewerk de services-array bovenaan script.js.
- Kleuren: bovenaan styles.css bij :root.
- Sfeerfoto's: vervang de achtergrond-URL's in styles.css door eigen bestanden.
- Teksten: bewerk index.html.

TIP
Open index.html eerst lokaal op een computer. Voor live hosting kun je de bestanden
rechtstreeks uploaden of integreren in de bestaande websiteomgeving.
